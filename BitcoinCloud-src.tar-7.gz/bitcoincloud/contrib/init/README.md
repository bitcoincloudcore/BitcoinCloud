Sample configuration files for:
```
SystemD: bitcoincloudd.service
Upstart: bitcoincloudd.conf
OpenRC:  bitcoincloudd.openrc
         bitcoincloudd.openrcconf
CentOS:  bitcoincloudd.init
macOS:    org.bitcoincloud.bitcoincloudd.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
